<!DOCTYPE html>
<html <?php language_attributes();?>>

<head>
	<!-- Basic Page Needs
    ================================================== -->
	<meta charset="<?php bloginfo('charset');?>" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />

	<!-- Specific Meta
    ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
	<?php wp_head();?>
</head>

<body data-bs-spy="scroll" data-bs-target=".navigation-area" <?php body_class();?>>
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Start Site Header
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<header class="site-header default-header-style">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-12">
				<div class="navigation-area">
					<!-- Site Branding -->
					<div class="site-branding">
						<a href="<?php echo esc_url(site_url())?>">
                            <?php
                            $custom_logo_id = get_theme_mod( 'custom_logo' );
                            $logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );

                            if ( has_custom_logo() ) {
	                            echo '<img src="' . esc_url( $logo[0] ) . '" alt="' . get_bloginfo( 'name' ) . '">';
                            } else {
	                            echo '<h1>' . get_bloginfo('name') . '</h1>';
                            }
                            ?>
						</a>
					</div><!--  /.site-branding -->

					<!-- Site Navigation -->
					<div class="site-navigation">
						<nav class="navigation">
							<!-- Main Menu -->
							<div class="menu-wrapper">
                                <?php
                                    wp_nav_menu(array(
	                                    'container'            => 'div',
	                                    'container_class'      => 'menu-content',
	                                    'menu_class'           => 'menu mainmenu',
	                                    'items_wrap'           => '<ul id="%1$s" class="%2$s">%3$s</ul>',
	                                    'theme_location'       => 'main-menu',
                                    ));
                                ?>

							</div><!-- /.menu-wrapper -->
						</nav>
					</div><!-- /.site-navigation -->
					<div class="hamburger-menus">
						<span></span>
						<span></span>
						<span></span>
					</div><!-- /.hamburger-menus -->
				</div><!-- /.navigation-area -->
			</div><!-- /.col-12 -->
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
	<div class="mobile-sidebar-menu sidebar-menu">
		<div class="overlaybg"></div>
	</div>
</header>
<!--~~./ end site header ~~-->