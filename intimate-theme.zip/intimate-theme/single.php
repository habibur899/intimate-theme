<?php get_header() ?>
    <!--********************************************************-->
    <!--********************* SITE CONTENT *********************-->
    <!--********************************************************-->
    <div class="site-content bg-white-smoke">
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			Start Blog Page Block
	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <div class="blog-page-block pd-t-100 pd-b-130">
        <div class="container container-1200">
            <div class="row">
                <div class="col-lg-8">
                    <div class="blog-single-page">
                        <article class="post single-post">
                            <figure class="post-thumb">
								<?php echo get_the_post_thumbnail() ?>
                            </figure><!-- /.post-thumb -->

                            <div class="post-details">
                                <h2 class="entry-title"><?php the_title() ?></h2><!-- /.entry-title -->
                                <div class="entry-content">
									<?php the_content(); ?>
                                </div><!-- /.entry-content -->
                            </div><!-- /.post-details -->
                            <div class="entry-footer">
                                <div class="entry-tag">
                                    <strong>Tags : </strong>
                                    <div class="tags">
                                        <?php echo get_the_tag_list()?>
                                    </div>
                                </div>
                                <!--/.entry-tag-->
                            </div>
                        </article><!-- /.post -->


                        <div id="comments" class="comments-area">
                            <div class="comments-main-content">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h3 class="section-heading comments-title"><?php if ( comments_open() ) {
												comments_popup_link( 'No comments yet', '1 comment', '% comments', 'comments-link', 'Comments are off for this post' );
											} ?></h3>
                                        <!--/.comments-title-->
                                    </div>
                                    <!--/.col-md-12-->
                                </div>
                                <!--/.row-->

                                <div class="row">
                                    <div class="col-md-12">
                                        <ol class="comment-list">
                                            <li class="comment">
                                                <div class="comment-body">
                                                    <div class="comment-meta">
                                                        <div class="comment-author vcard">
                                                            <div class="author-img">
                                                                <img alt="" src="assets/images/blog/comments/1.png"
                                                                     class="avatar photo">
                                                            </div>
                                                        </div>
                                                        <!--/.comment-author-->
                                                        <div class="comment-metadata"><b class="author">Makado
                                                                Smith</b>
                                                            <span class="date"> 10:35pm, 27 jan 2015.</span>
                                                        </div>
                                                        <!--/.comment-metadata-->
                                                    </div>
                                                    <!--/.comment-meta-->
                                                    <div class="comment-details">
                                                        <div class="comment-content">
                                                            <p>Coding is used in almost all aspects of life and work
                                                                now, be it directly or
                                                                indirectly. It’s not just for companies in the tech
                                                                sector. “An increasing number of
                                                                businesses rely on computer code,</p>
                                                        </div>
                                                        <!--/.comment-content-->
                                                        <a href="#" class="comment-reply-link">Reply</a>
                                                    </div><!-- /.comment-details-->
                                                </div>
                                                <!--/.comment-body-->
                                            </li>
                                            <!--/.comment-body-->
                                            <li class="comment">
                                                <div class="comment-body">
                                                    <div class="comment-meta">
                                                        <div class="comment-author vcard">
                                                            <div class="author-img">
                                                                <img alt="" src="assets/images/blog/comments/2.png"
                                                                     class="avatar photo">
                                                            </div>
                                                        </div>
                                                        <!--/.comment-author-->
                                                        <div class="comment-metadata"><b class="author">Willams
                                                                Doe</b>
                                                            <span class="date"> 10:35pm, 27 jan 2015.</span>
                                                        </div>
                                                        <!--/.comment-metadata-->
                                                    </div>
                                                    <!--/.comment-meta-->
                                                    <div class="comment-details">
                                                        <div class="comment-content">
                                                            <p>Coding is used in almost all aspects of life and work
                                                                now, be it directly or
                                                                indirectly. It’s not just for companies in the tech
                                                                sector.
                                                            </p>
                                                        </div>
                                                        <!--/.comment-content-->
                                                        <a href="#" class="comment-reply-link">Reply </a>
                                                    </div><!-- /.comment-details-->
                                                </div>
                                                <!--/.comment-body-->
                                            </li>
                                            <!--/.comment-body-->
                                        </ol>
                                        <!--/.comment-list-->
                                    </div>
                                    <!--/.col-md-12-->
                                </div>
                                <!--/.row-->
                            </div><!-- /.comments-main-content -->
                        </div><!-- /.comments-area -->

                        <div class="comment-respond">
                            <form action="<?php echo get_the_permalink()?>" class="comment-form">
								<?php
								$comments_args = array(
									// Change the title of send button
									'label_submit'        => __( 'Send', 'porimoni' ),
									// Change the title of the reply section
									'title_reply'         => __( 'Write a Reply or Comment', 'porimoni' ),
									// Remove "Text or HTML to be displayed after the set of comment fields".
									'comment_notes_after' => '',
									// Redefine your own textarea (the comment body).
									'comment_field'       => '<p class="comment-form-comment"><label for="comment">' . _x( 'Comment', 'noun' ) . '</label><br /><textarea id="comment" name="comment" aria-required="true"></textarea></p>',
								);
								comment_form( $comments_args );
								?>
                            </form>
                        </div>
                    </div><!--  /.blog-latest-items -->
                </div><!-- /.col-lg-8 -->

                <div class="col-lg-4">
                    <!-- Sidebar Items -->
                    <div class="sidebar-items">
						<?php if ( is_active_sidebar( 'sidebar-1' ) ) {
							dynamic_sidebar( 'sidebar-1' );
						} ?>
                    </div><!--  /.sidebar-items -->
                </div><!-- /.col-lg-4 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div>
    <!--~~./ end blog page ~~-->
<?php get_footer() ?>