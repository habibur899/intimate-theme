<?php get_header(); ?>


<div class="site-content bg-white-smoke">
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		Start Page Title Area
	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <div class="page-title-area bg-white-smoke">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="page-header-content">
                        <div class="page-header-caption">
                            <h2 class="page-title"><?php echo esc_html( wp_title() ) ?></h2>
                        </div>
                        <!--~~./ page-header-caption ~~-->
                    </div>
                    <!--~~./ page-header-content ~~-->
                </div>
            </div>
        </div>
        <!--~~./ end container ~~-->
    </div>
    <!--~~./ end page title area ~~-->

    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		Start Blog Page Block
	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <div class="blog-page-block bg-white-smoke pd-b-130">
        <div class="container">
            <!-- Content Row -->
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <!-- Blog Items -->
                    <div class="blog-latest-items">

						<?php
						if ( have_posts() ) {
							while ( have_posts() ) {
								the_post(); ?>
                                <article class="post">
                                    <figure class="post-thumb">
                                        <a href="<?php echo esc_url( get_the_permalink() ) ?>">
                                            <img src="<?php echo esc_url( get_the_post_thumbnail_url(), 'full' ) ?>"
                                                 alt="<?php the_title() ?>"/>
                                        </a>
                                    </figure><!-- /.post-thumb -->

                                    <div class="post-details">
                                        <!-- /.entry-title -->
                                        <div class="entry-meta">
                                            <div class="entry-category">
												<?php
												echo get_the_category_list( ' ' );
												?>
                                            </div>
                                            <!--./ entry-category -->
                                            <div class="entry-date"><?php echo get_the_date( 'F j - Y' ) ?></div>
                                            <!--./ entry-date -->
                                        </div>
                                        <!-- /.entry-meta -->
                                        <div class="post-body">
                                            <h2 class="entry-title">
                                                <a href="<?php echo esc_url( get_the_permalink() ) ?>"><?php esc_html__( the_title(), 'intimate' ) ?></a>
                                            </h2>
                                            <div class="entry-content">
                                                <p>
													<?php echo esc_html__( wp_trim_words( get_the_content(), '35', ' ' ), 'intimate' ) ?>
                                                </p>
                                                <div class="read-more-wrapper">
                                                    <a class="read-more"
                                                       href="<?php echo esc_url( get_the_permalink() ) ?>"><?php echo esc_html__( 'READ MORE', 'intimate' ) ?></a>
                                                </div>
                                            </div>
                                            <!-- /.entry-content -->
                                        </div>
                                    </div><!-- /.post-details -->
                                </article><!-- /.post -->

								<?php
							}
						}
                        wp_reset_query();
						?>


                    </div>
                    <!-- /.blog-latest-items -->

                    <!--~~~~~ Start Paging Navigation ~~~~~-->

                    <nav class="paging-navigation paging-center pd-t-10">
						<?php
						function intimate_pagination() {
							global $wp_query;
							$links = paginate_links( array(
								'current' => max( 1, get_query_var( 'paged' ) ),
								'total'   => $wp_query->max_num_pages,
								'type'    => 'list',
								'mid_size'           => 3,
								'prev_text'          => __( '<i class="fas fa-chevron-left"></i>' ),
								'next_text'          => __( '<i class="fas fa-chevron-right"></i>' ),
							) );
							$links = str_replace( 'nav-links', 'page-numbers', $links );
							$links = str_replace( "<ul class='page-numbers'>", '<ul class="nav-links">',$links );
							echo $links;
						}

						intimate_pagination();

						?>
                    </nav>
                    <!--~./ end paging navigation ~-->
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </div>
    <!--~~./ end blog page ~~-->

	<?php get_footer(); ?>

