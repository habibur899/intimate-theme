<?php
// Page
get_header();
the_content();
get_footer();