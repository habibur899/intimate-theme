<?php
function intimate_demo_import() {
	return [
		[
			'import_file_name'           => 'Intimate Demo Import',
			'import_file_url'            => get_template_directory_uri() . '/inc/demo-content/intimate-main-content.xml',
			'import_widget_file_url'     => get_template_directory_uri() . '/inc/demo-content/intimate-widget.wie',
			'import_customizer_file_url' => get_template_directory_uri() . '/inc/demo-content/intimate-customizer.dat',
		]
	];
}

add_filter( 'ocdi/import_files', 'intimate_demo_import' );